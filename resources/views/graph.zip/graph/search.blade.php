@extends('layouts.simple.master')
@section('title', 'Apex Chart')

@section('css')
<link rel="stylesheet" type="text/css" href="{{asset('assets/css/vendors/daterange-picker.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('assets/css/vendors/datatables.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('assets/css/vendors/owlcarousel.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('assets/css/vendors/rating.css')}}">

@endsection

@section('style')
@endsection

@section('breadcrumb-title')

@endsection

@section('breadcrumb-items')
<li class="breadcrumb-item">Charts</li>

@endsection

@section('content')

<!-- Fields -->
<!-- End Fields -->


<div class="container-fluid">
	<div class="row">
        
		<div class="col-sm-12 col-xl-12 box-col-12">
			<div class="card">
                
            <!-- <div class="card-header">
					<h5>Mixed Chart</h5>
				</div> -->

                <form class="needs-validation search_form"  novalidate="" action="{{route('search_data')}}" method="post" enctype="multipart/form-data">
					@csrf
						<div class="row">

                                                        
                                                            @if ($message = Session::get('success'))
                                            <div class="alert alert-success">
                                                <p>{{ $message }}</p>
                                            </div>
                                        @endif

                                        @if ($message = Session::get('error'))
                                            <div class="alert alert-danger">
                                                <p>{{ $message }}</p>
                                            </div>
                                        @endif
									<div class="col-md-2 mb-2">
                                       <p style="font-weight: bold;font-size: 15px;">Select Brand</p>
										<!-- <div class="col-form-label">Select Brand</div> -->
                                        @if(auth()->user()->user_type != 2)
										<select class="js-example-placeholder-multiple col-sm-12 form-control" id="brand_id" name="brand" data-href="{{ route('get_coupons') }}">
                                            <option value="">Select Brand</option>
                                            @foreach($brands as $br)
                                                @if(isset($brand) && $brand == $br->id)
                                                <option value="{{ $br->id }}" selected>{{ $br->company_name }}</option>
                                                @else
                                                <option value="{{ $br->id }}">{{ $br->company_name }}</option>
                                                @endif
                                            @endforeach
                                            
										</select>
                                        @else
                                        <select class="js-example-placeholder-multiple col-sm-12 form-control" name="brand">
                                            <option value="">Select Brand</option>
                                            @foreach($brands as $br)
                                                @if(isset($brand) && $brand == $br->id)
                                                <option value="{{ $br->id }}" selected>{{ $br->company_name }}</option>
                                                @else
                                                <option value="{{ $br->id }}">{{ $br->company_name }}</option>
                                                @endif
                                            @endforeach
                                            
										</select>
                                        @endif
										
									</div>
                                    @if(auth()->user()->user_type != 2)
                                    <div class="col-md-3 mb-2">
                                       <p style="font-weight: bold;font-size: 15px;">Select Influencer</p>
										<!-- <div class="col-form-label">Select Brand</div> -->
                                        
										<select class="js-example-placeholder-multiple col-sm-12 form-control" name="influencer">
                                        <option value="">Select Influencer</option>
                                        @foreach($influencers as $in)
                                            @if(isset($influencer) && $influencer == $in->id)
											<option value="{{$in->id}}" selected>{{$in->f_name}}</option>
                                            @else
                                            <option value="{{$in->id}}">{{$in->f_name}}</option>
                                            @endif
											@endforeach
										</select>
                                       
										
									</div>
                                    @else
                                        <input type="hidden" name="influencer" class="form-control" value="{{ auth()->user()->id }}" readonly>

                                        @endif
                                    <div class="col-md-2 mb-2">
                                       <p style="font-weight: bold;font-size: 15px;">Select Coupon</p>
										<!-- <div class="col-form-label">Select Brand</div> -->
                                        @if(auth()->user()->user_type != 2)
										<select class="js-example-placeholder-multiple col-sm-12 form-control" id="coupon_id" name="coupon">
                                        <option value="">Select Coupon</option>
                                      
                                        @foreach($coupons as $cop)
                                        <option value="{{ $cop->id }}"
												{{ $cop->id == (isset($coupon) ? $coupon : 0) ? 'selected' : '' }}>
												{{ $cop->coupon_code }}</option>
										@endforeach
										</select>
                                        @else
                                        <select class="js-example-placeholder-multiple col-sm-12 form-control" name="coupon">
                                        <option value="">Select Coupon</option>
                                      
                                        @foreach($coupons as $cop)
                                        <option value="{{ $cop->id }}"
												{{ $cop->id == (isset($coupon) ? $coupon : 0) ? 'selected' : '' }}>
												{{ $cop->coupon_code }}</option>
										@endforeach
										</select>
                                        @endif
										
									</div>

                                    

                                    <!-- <div class="col-md-2 mb-2">
                                       <p style="font-weight: bold;font-size: 15px;">Date</p>
										<div class="col-form-label">Select Brand</div>
										<select class="js-example-placeholder-multiple col-sm-12 form-control" name="influencer">
                                        <option value="" disabled selected>Select Date</option>
											<option value=""></option>
											
										</select>
										
									</div> -->

                                    <div class="col-md-2 mb-2">
                                       <p style="font-weight: bold;font-size: 15px;"> Select Template</p>
										<!-- <div class="col-form-label">Select Brand</div> -->
										<select class="js-example-placeholder-multiple col-sm-12 form-control" name="template">
										
                                            <option value="">Select Template</option>
											<option value="1" >Template 1</option>
                                            <option value="2" >Template 2</option>
                                            <option value="3" >Template 3</option>
										</select>
										
									</div>
								
                                    <div class="col-md-2 mb-2">
                                       <p style="font-weight: bold;font-size: 15px;"> Select Filter</p>
										<!-- <div class="col-form-label">Select Brand</div> -->
										<select class="js-example-placeholder-multiple col-sm-12 form-control" name="filter">
										
                                            <option value="">Select Filter</option>
											<option value="revenue" {{ (isset($filter) && $filter == "revenue") ? 'selected': ''  }} >Revenue</option>
                                            <option value="sa" {{ (isset($filter) && $filter == "sa") ? 'selected': ''  }}>Sale Amount</option>
                                            <option value="order" {{ (isset($filter) && $filter == "order") ? 'selected': ''  }}>Orders</option>
										</select>
										
									</div>
                                    <div class="col-md-2 mb-2">
                                       <p style="font-weight: bold;font-size: 15px;">Select Currency</p>
										<!-- <div class="col-form-label">Select Brand</div> -->
                                        @if(auth()->user()->user_type != 2)
										<select class="js-example-placeholder-multiple col-sm-12 form-control" name="currency">
                                            <option value="">Select Currency</option>
                                            @foreach($currencies as $curr)
                                                @if(isset($currency) && $currency == $curr->currency)
                                                <option value="{{ $curr->currency }}" selected>{{ $curr->currency }}</option>
                                                @else
                                                <option value="{{ $curr->currency }}">{{ $curr->currency }}</option>
                                                @endif
                                            @endforeach
                                            
										</select>
										@else
                                        <select class="js-example-placeholder-multiple col-sm-12 form-control" name="currency">
                                            <option value="">Select Currency</option>
                                            @foreach($currencies as $curr)
                                                @if(isset($currency) && $currency == $curr)
                                                <option value="{{ $curr }}" selected>{{ $curr}}</option>
                                                @else
                                                <option value="{{ $curr }}">{{ $curr }}</option>
                                                @endif
                                            @endforeach
                                            
										</select>
                                        @endif
									</div>

                                       <div class="theme-form">
						<div class="col-md-3 mb-3">
                        <p style="font-weight: bold;font-size: 15px;"> Select Date</p>

							<input class="form-control digits" type="text" value="{{ isset($daterange) ? $daterange : '' }}" name="daterange" >
						</div>
					</div>
							
						</div>
						<div class="mb-3">
							
						</div>
						<button class="btn btn-success" type="submit">Search</button>
					</form>


				<div class="card-body">
					<div id="mixedchart"></div>
				</div>

                
			</div>
		    </div>
		
	
		
		</div>
        <div class="col-sm-12 col-xl-12 box-col-12">
            <div class="row justify-content-center m-0">
                <div class="col-sm-3 px-1">
                    <div class="card data_show h-100">
                        <h5 class="text-center p-2">Total Revenues</h5>
                        <h5 class="text-center" style="font-size: 34px;">{{ round($total_revenues,2) }}</h5>
                    </div>
                </div>
                <div class="col-sm-3 px-1">
                    <div class="card data_show h-100">
                        <h5 class="text-center p-2">Total Sale Amount</h5>
                        <h5 class="text-center" style="font-size: 34px;"> {{ round($total_sale_amount,2) }} </h5>
                    </div>
                </div>
                
                <div class="col-sm-3 px-1">
                    <div class="card data_show h-100">
                        <h5 class="text-center p-2">Total Orders</h5>
                        <h5 class="text-center" style="font-size: 34px;">{{ $total_orders }}</h5>
                    </div>
                </div>
            </div>
        </div>
        <div class="mt-5 card p-5">
        <table class="display" id="basic-2">
                     <thead>
                        <tr>

                        <th>#</th>
                        <th>Brand</th>
                        <th>Coupon</th>
                        <th>Revenue</th>
                        <th>Sale Amount</th>
                        <th>Sale Amount USD</th>
                        <th>Orders</th>
                        <th>AOV</th>
                        <th>AOV USD</th>
                        <th>Date</th>
                           
                          
                        </tr>
                     </thead>
                     <tbody>
                     @php($i = 1)
                     @foreach($all_data as $all_dat)
                     <?php
                       $brand = App\Models\Brand::find($all_dat->brand_id);
                       $coupon = App\Models\Coupon::find($all_dat->coupon_id)
                     ?>
                     
                        <tr>

                        <th scope="row">{{$loop->iteration}}</th>
                        
                            <td>
                              <div class="some_text">
                                 {{ isset($brand) ? $brand->company_name : ''}}
                              </div>
                           </td>

                           <td>
                              <div class="some_text">
                                 {{ isset($coupon) ? $coupon->coupon_code : ''}}
                              </div>
                           </td>
                           
                           <td>
                              <div class="some_text">
                                 {{ $all_dat->revenue}}
                              </div>
                           </td>
                           <td>{{ $all_dat->sale_amount}}</td>
                           <td>{{ $all_dat->sale_amount_usd}}</td>
                           <td>{{ $all_dat->orders}}</td>
                           <td>{{ $all_dat->aov}}</td>
                           <td>{{ $all_dat->aov_usd}}</td>
                           
                           <td>{{ $all_dat->date}}</td>
                        </tr>
            
                    @endforeach
                       
                     </tbody>
        </table>
        </div>
        
	</div>
</div>
@endsection

@section('script')
<script src="{{asset('assets/js/chart/apex-chart/apex-chart.js')}}"></script>
<script src="{{asset('assets/js/chart/apex-chart/stock-prices.js')}}"></script>
<script src="{{asset('assets/js/chart/apex-chart/chart-custom.js')}}"></script>
<script src="{{asset('assets/js/datepicker/daterange-picker/moment.min.js')}}"></script>
<script src="{{asset('assets/js/datepicker/daterange-picker/daterangepicker.js')}}"></script>
<script src="{{asset('assets/js/datepicker/daterange-picker/daterange-picker.custom.js')}}"></script>

<script src="{{asset('assets/js/datatable/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('assets/js/rating/jquery.barrating.js')}}"></script>
<script src="{{asset('assets/js/rating/rating-script.js')}}"></script>
<script src="{{asset('assets/js/owlcarousel/owl.carousel.js')}}"></script>
<script src="{{asset('assets/js/ecommerce.js')}}"></script>
<script src="{{asset('assets/js/product-list-custom.js')}}"></script>

@if(isset($all_data) && empty($filter))

<script>
var cont = "{{ count($all_data) }}";
var d_cont = "{{ count($dates) }}";

var options7 = {
    chart: {
        height: 350,
       
        type: 'line',
        stacked: false,
        toolbar:{
          show: false
        }
    },
    stroke: {
        // width: [0, 2, 5],
        curve: 'smooth'
    },
    plotOptions: {
        bar: {
            columnWidth: '50%'
        }
    },
    series: [{
        name: 'Revenue',
        type: 'area',
        data: [<?php if($template == 3){ $d_count = count($dates);  foreach ($all_data as $data) {
                        if($d_count > 0){
                            echo $data->revenue.",";
                        }
                         $d_count--;
                     }} ?>]
    }, {
        name: 'Sale Amount',
        type: 'area',
        data: [<?php if($template == 1){ $d_count = count($dates);  foreach ($all_data as $data) {
                        if($d_count > 0){
                            echo $data->sale_ammount.",";
                        }
                         
                        $d_count--;
                     }} ?>]
    }, 
     {
        name: 'Orders',
        type: 'area',
        data: [<?php if($template == 2){ $d_count = count($dates); foreach ($all_data as $data) {
                         if($d_count > 0){
                            echo $data->order.",";
                        }
                         
                         $d_count--;
                     }} ?>]
    }],
    fill: {
        opacity: [0.85,0.25,1],
        gradient: {
            inverseColors: false,
            shade: 'light',
            type: "vertical",
            opacityFrom: 0.85,
            opacityTo: 0.55,
            // stops: [0, 100, 100, 100]
        }
    },
    labels: 
        [<?php
            if (count($dates) > 0) {
                $kkk=0;
                foreach ($dates as $date) {
                    if ($kkk != (count($dates) -1)) {
                        echo "'".$date . "',";
                    } else {
                        echo "'".$date."'";
                    }
                    $kkk++;
                }
            }
            ?>],
    markers: {
        size: 0
    },
    xaxis: {
        type:'date'
    },
    yaxis: {
        min: 0
    },
    tooltip: {
        shared: true,
        intersect: false,
        y: {
            formatter: function (y) {
                if(typeof y !== "undefined") {
                    return  y.toFixed(0) + " views";
                }
                return y;

            }
        }
    },
    legend: {
        labels: {
            useSeriesColors: true
        },
    },
    colors:[CubaAdminConfig.secondary , '#51bb25' , CubaAdminConfig.primary ]
}
    var chart7 = new ApexCharts(
    document.querySelector("#mixedchart"),
    options7
);

chart7.render();
</script>
@elseif(isset($all_data) && isset($filter) && !empty($filter))

<script>
var filter = "";
var d_cont = "{{ count($dates) }}";
<?php if ($filter == "revenue") {?>
            filter = 'Revenue';
            <?php } elseif ($filter == "sa") {?>
                filter = 'Sale Amount';
            
            <?php } elseif ($filter == "order") {?>
                filter = 'Orders';
            <?php } ?>;

var options7 = {
    chart: {
        height: 350,
        
        type: 'area',
        stacked: false,
        toolbar:{
          show: false
        }
    },
    stroke: {
        // width: [0, 2, 5],
        curve: 'smooth'
    },
    plotOptions: {
        bar: {
            columnWidth: '50%'
        }
    },
    series: [{
        name: filter,
        type: 'area',
        data: [<?php $k=0;  foreach ($all_data as $data) {
                if ($k != (count($all_data) - 1)) {
                    if ($filter == "revenue") {
                        echo $data->revenue.",";
                    } elseif ($filter == "sa") {
                        echo $data->sale_ammount.",";
                    } elseif ($filter == "order") {
                        echo $data->order.",";
                    }
                } else {
                    if ($filter == "revenue") {
                        echo $data->revenue;
                    } elseif ($filter == "sa") {
                        echo $data->sale_ammount;
                    } elseif ($filter == "order") {
                        echo $data->order;
                    }
                }
            
             
                $k++;
            } ?>]
    }],
    fill: {
        opacity: [0.85,0.25,1],
        gradient: {
            inverseColors: false,
            shade: 'light',
            type: "vertical",
            opacityFrom: 0.85,
            opacityTo: 0.55,
            stops: [0, 100, 100, 100]
        }
    },
    labels: [<?php
            if (count($dates) > 0) {
                $kkk=0;
                foreach ($dates as $date) {
                    if ($kkk != (count($dates) -1)) {
                        echo "'".$date . "',";
                    } else {
                        echo "'".$date."'";
                    }
                    $kkk++;
                }
            }
            ?>],//['01/01/2003', '02/01/2003','03/01/2003','04/01/2003','05/01/2003','06/01/2003','07/01/2003','08/01/2003','09/01/2003','10/01/2003','11/01/2003'],
    markers: {
        size: 0
    },
    xaxis: {
        type:'date'
    },
    yaxis: {
        min: 0
    },
    tooltip: {
        shared: true,
        intersect: false,
        y: {
            formatter: function (y) {
                if(typeof y !== "undefined") {
                    return  y.toFixed(0) + " views";
                }
                return y;

            }
        }
    },
    legend: {
        labels: {
            useSeriesColors: true
        },
    },
    colors:[CubaAdminConfig.secondary , '#51bb25' , CubaAdminConfig.primary ]
}
    var chart7 = new ApexCharts(
    document.querySelector("#mixedchart"),
    options7
);

chart7.render();
</script>

@endif
<script>
	$(document).on('change','#brand_id',function(){
            let brand_id = $(this).val();
            let url = $(this).attr('data-href');
            getCategory(url,brand_id);
        });

		function getCategory(url,brand_id){
            $.get(url+'?brand_id='+brand_id,function(data){
                let response = data.data;
                let view_html = ``;
                $.each(response , function(key, value) {
                    view_html += `<option value="${value.id}">${value.coupon_code}</option>`;
                  });
                  console.log(view_html)
                  let start = `<option value="">Select One</option>`;
                $('#coupon_id').html(start+view_html);
            })
        }
</script>
@endsection